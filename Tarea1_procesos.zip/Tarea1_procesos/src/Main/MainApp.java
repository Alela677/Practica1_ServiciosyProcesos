package Main;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainApp {

	private static ProcessBuilder proceso;

	public static void main(String[] args) {
		
		// Diferentes contadores para el ejercicio
		int numLinea = 0;
		int sumadorLineas = 0;
		int numFicheros = 0;
		
		// Buscamos el archivo con la clase File y pasamos un listado con las rutas relativas de los ficheros
		File carpeta = new File("Ficheros");
		File[] listado = carpeta.listFiles();
		
		//Recorremos la lista y ejecutamos el proceso por cada ruta encontrada y ejecutamos los contadores oportunos para sacar los numeros 
		// que pide el ejercicio e imprimimos los resultados
		for (int i = 0; i < listado.length; i++) {
			numFicheros++;
			//Comando find /v /c "" + "nombre" del archivo que cuentas las linea de un directori o un fichero en concreto
			proceso = new ProcessBuilder("find", "/v", "/c", "\"\"", listado[i].getAbsolutePath());

			try {

				Process p1 = proceso.start();
				InputStream stt = p1.getInputStream();

				BufferedReader read = new BufferedReader(new InputStreamReader(stt));

				String linea = read.readLine();
			
				while (linea != null) {
//					System.out.println(linea);
					String[] partes = linea.split(":");
					for (int j = 0; j < partes.length - 1; j++) {
//						System.out.println(partes[2]);
						numLinea = Integer.parseInt(partes[2].substring(1));
						sumadorLineas = sumadorLineas + numLinea;

					}

//					System.out.println(numLinea);

					linea = read.readLine();

				}

				System.out.println("Linea por ficheros : " + numLinea);

				read.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

//			System.out.println(listado[i].getAbsolutePath());
		}
		System.out.println("La suma de todas las linea de los fichero del directorio es : " + sumadorLineas);
		System.out.println("Numero de fichero encontrados : " + numFicheros);
	}
}
